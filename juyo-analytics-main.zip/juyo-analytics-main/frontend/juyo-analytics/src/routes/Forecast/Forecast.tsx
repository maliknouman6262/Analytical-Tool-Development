import React from "react";
import AppLayout from "../../components/Layout/AppLayout";
export default function Forecast() {
  return <AppLayout Children={<div>This page is Coming Soon</div>} />;
}
